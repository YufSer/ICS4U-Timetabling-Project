####################################################################################################
## File Name: ttClasses002.py
## Date: 2017-05-22
## Description: Contains the classes for the timetabling software.
##              This version includes a Chromosome object that can update its fitness score, as
##              well as crossover and mutate.
####################################################################################################

import random

CROSSOVER_CHANCE = 0.7
MUTATION_CHANCE = 0.001

def clear_end(bits, new_end):
    '''Set all bits after a certain slice to 0.

    >>> bits = int('0b1010101', 2)
    >>> bin(clear_end(bits, 3))
    '0b101'
    '''
    mask = (1 << new_end) - 1   # creates a string of 1's of length (new_end)
    return bits & mask          # bitwise AND sets all bits after that string to 0   

def get_bits(bits, start, stop):
    '''Return the bits between two slices of a binary string

    >>> bits = int('0b1110111', 2)
    >>> bin(get_bits(bits, 2, 6))
    '0b1101'
    '''
    # remove the bits after the stop slice and before the start slice  
    return clear_end(bits, stop) >> start                           

def concatenate_bits(left, right, right_length):
    '''Add the bits of a binary string to those of another.

    >>> left = int('0b10101', 2)
    >>> right = int('0b1111', 2)
    >>> bin(concatenate_bits(left, right, 4))
    '0b101011111'
    >>> bin(concatenate_bits(left, right, 8))
    '0b1010100001111'
    '''
    # bit shift left the correct number of spaces, then set the bits of the right using bitwise OR
    return (left << right_length) | right

class Chromosome(object):
    '''Object describing the timeslot in which each course section runs.

    Consists of a string of bits and an associated fitness score. Every three
    bits represents a timeslot (from 0-7) in which a certain course section runs.
    '''
    def __init__(self, size, bits = None):
        if bits is None:
            bits = int(random.getrandbits(size))
        self.size = size
        self.bits = bits
        self.fitness = 0

    def decode(self):
        '''Returns a list of integers from 0-7, representing the timeslots of each section.'''
        periods = []
        for i in xrange(0, self.size, 3):               # break the chromosome into threes
            period = int(get_bits(self.bits, i, i+3))   # and create a list of the associated
            periods.append(period)                      # integers from 0-7
        return periods

    def update_fitness(self, students):
        fitness = 0
        periods = self.decode()
        
        for student in students:            # iterate through each student
            sections = student[1]           # get the course sections in which the student is enrolled
            busy = []                       # list of periods during which the student has a class
            
            for section in sections:        # iterate through each of the student's sections
                period = periods[section]   # get the period in which that section runs
                
                if period not in busy:      # if the student is not busy during that period
                    fitness += 1            # increment the fitness score
                    busy.append(period)     # add that period to busy

        self.fitness = fitness

    def crossover(self, other):
        '''Swap the head of this chromosome with the tail of another and return the resultant two chromosomes'''
        # roll for whether the crossover will occur or not
        if random.random() < CROSSOVER_CHANCE:
            
            # choose a random position at which to split the chromosomes
            pos = random.randrange(1, self.size)
            
            # add the head of self to the tail of other
            crossed1 = concatenate_bits(self.bits >> pos, clear_end(other.bits, pos), pos)

            # add the head of other to the tail of self
            crossed2 = concatenate_bits(other.bits >> pos, clear_end(self.bits, pos), pos)

            # return the resultant chromosomes
            return Chromosome(self.size, crossed1), Chromosome(other.size, crossed2)
        else:
            # create new chromosome objects to avoid altering the original chromosomes
            return Chromosome(self.size, self.bits), Chromosome(other.size, other.bits)

    def mutate(self):
        '''Iterate through the bits of a chromosome, and flip certain bits according to a percent chance.'''
        for i in xrange(self.size):
            if random.random() < MUTATION_CHANCE:
                self.bits = self.bits ^ (1 << i) # flip the bit using XOR
        
# NOTE: CREATE POPULATION CLASS WITH NUMBER OF SECTIONS, WHICH IT THEN CONVERTS TO A SIZE
