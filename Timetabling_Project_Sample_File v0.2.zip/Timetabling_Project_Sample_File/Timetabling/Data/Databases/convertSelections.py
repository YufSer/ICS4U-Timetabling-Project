import os, sqlite3, csv 

path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'CSV Files', 'course_selection.csv'))

try:
    os.remove('selections.db')
except WindowsError:
    pass

con = sqlite3.connect('selections.db')
cur = con.cursor()

cur.execute('''
CREATE TABLE Selections(
Name TEXT,
Gender TEXT,
StudentNumber INTEGER,
Grade INTEGER,
C1 TEXT,
C2 TEXT,
C3 TEXT,
C4 TEXT,
C5 TEXT,
C6 TEXT,
C7 TEXT,
C8 TEXT,
C9 TEXT,
C10 TEXT,
CourseCount INTEGER,
PRIMARY KEY(StudentNumber))
''')

with open(path, 'r') as f:
    reader = csv.DictReader(f)
    dbList = []
    for i in reader:
        dbList.append([i['St Name'],
                       i['St Gender'],
                       i['St Num'],
                       i['Grade'],
                       i['C1'],
                       i['C2'],
                       i['C3'],
                       i['C4'],
                       i['C5'],
                       i['C6'],
                       i['C7'],
                       i['C8'],
                       i['C9'],
                       i['C10'],
                       i['crs_count']])

for row in dbList:
    for i in range(len(row)):
        if row[i] == '':
            row[i] = None
            
cur.executemany("INSERT INTO selections VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", dbList)
con.commit()

con.close()

