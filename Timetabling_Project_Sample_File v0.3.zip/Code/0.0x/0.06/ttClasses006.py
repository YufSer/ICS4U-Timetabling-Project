####################################################################################################
## File Name: ttClasses006.py
## Date: 2017-05-31
## Description: Contains the classes for the timetabling software.
####################################################################################################

import random, copy

CROSSOVER_CHANCE = 0.7
MUTATION_CHANCE = 0.001
SWAP_CHANCE = 0.05

POPULATION_SIZE = 150
NUM_ELITES = 4
NUM_COPIES = 1

def clear_end(bits, new_end):
    '''Set all bits after a certain slice to 0.

    >>> bits = int('0b1010101', 2)
    >>> bin(clear_end(bits, 3))
    '0b101'
    '''
    mask = (1 << new_end) - 1   # creates a string of 1's of length (new_end)
    return bits & mask          # bitwise AND sets all bits after that string to 0   

def get_bits(bits, start, stop):
    '''Return the bits between two slices of a binary string

    >>> bits = int('0b1110111', 2)
    >>> bin(get_bits(bits, 2, 6))
    '0b1101'
    '''
    # remove the bits after the stop slice and before the start slice  
    return clear_end(bits, stop) >> start                           

def concatenate_bits(left, right, right_length):
    '''Add the bits of a binary string to those of another.

    >>> left = int('0b10101', 2)
    >>> right = int('0b1111', 2)
    >>> bin(concatenate_bits(left, right, 4))
    '0b101011111'
    >>> bin(concatenate_bits(left, right, 8))
    '0b1010100001111'
    '''
    # bit shift left the correct number of spaces, then set the bits of the right using bitwise OR
    return (left << right_length) | right

class Chromosome(object):
    '''Object describing the timeslot in which each course section runs.

    Consists of a string of bits and an associated fitness score. Every three
    bits represents a timeslot (from 0-7) in which a certain course section runs.
    '''
    def __init__(self, size, students, bits = None):
        if bits is None:
            bits = int(random.getrandbits(size))
        self.size = size
        self.students = students
        self.bits = bits
        self.fitness = 0

    def decode(self):
        '''Returns a list of integers from 0-7, representing the timeslots of each section.'''
        periods = []
        for i in xrange(0, self.size, 3):               # break the chromosome into threes
            period = int(get_bits(self.bits, i, i+3))   # and create a list of the associated
            periods.append(period)                      # integers from 0-7
        return periods

    def update_fitness(self):
        periods = self.decode()
        collisions = 0
        
        for sections in self.students:
            busy = set()
            for section in sections:
                busy.add(periods[section])
            collisions += len(sections) - len(busy)

        try:
            self.fitness = 1/float(collisions)
        except ZeroDivisionError:
            self.fitness = float('inf')
            
    def crossover(self, other):
        '''Swap the head of this chromosome with the tail of another and return the resultant two chromosomes.'''
        if random.random() < CROSSOVER_CHANCE:
            pos = random.randrange(1, self.size)
            crossed1 = concatenate_bits(self.bits >> pos, clear_end(other.bits, pos), pos)
            crossed2 = concatenate_bits(other.bits >> pos, clear_end(self.bits, pos), pos)

            pos = random.randrange(1, len(self.students))
            students1 = self.students[:pos] + other.students[pos:]
            students2 = other.students[:pos] + self.students[pos:]
                
            return Chromosome(self.size, students1, crossed1), Chromosome(other.size, students2, crossed2)
        else:
            return self, other

    def mutate(self, altSections):
        '''Iterate through the bits of a chromosome, and flip certain bits according to a percent chance.'''
        for i in xrange(self.size):
            if random.random() < MUTATION_CHANCE:
                self.bits = self.bits ^ (1 << i) # flip the bit using XOR

        for i in xrange(len(self.students)):
            for j in xrange(len(self.students[i])):
                if random.random() < SWAP_CHANCE:
                    self.students[i][j] = random.choice(altSections[self.students[i][j]])
                        
    def randomize_students(self, altSections):
        for i in xrange(len(self.students)):
            for j in xrange(len(self.students[i])):
                self.students[i][j] = random.choice(altSections[self.students[i][j]])
        
class Population(object):
    '''Object consisting of a list of chromosomes.'''
    def __init__(self, size, students, altSections):
        self.chromosomes = [Chromosome(size, copy.deepcopy(students)) for i in xrange(POPULATION_SIZE)]
        self.total_fitness = 0
        self.best = self.chromosomes[0]
        self.altSections = altSections

        for chromosome in self.chromosomes:
            chromosome.randomize_students(self.altSections)

    def update_fitnesses(self):
        self.total_fitness = 0
        for chromosome in self.chromosomes:
            chromosome.update_fitness()
            self.total_fitness += chromosome.fitness
            if chromosome.fitness > self.best.fitness:
                self.best = chromosome

    def choose_chromosome(self):
        threshold = self.total_fitness * random.random()
        total = 0
        for chromosome in self.chromosomes:
            total += chromosome.fitness
            if total > threshold:
                return chromosome
        return chromosome

    def get_elites(self):
        sorted_chromosomes = sorted(self.chromosomes, key = lambda chromosome: chromosome.fitness)
        elites = sorted_chromosomes[-NUM_ELITES:] * NUM_COPIES
        return elites

    def run_generation(self):
        self.update_fitnesses()
        next_gen = self.get_elites()

        while len(next_gen) < POPULATION_SIZE:
            choice1 = self.choose_chromosome()
            choice2 = self.choose_chromosome()
            choice1, choice2 = choice1.crossover(choice2)
            next_gen.extend([choice1, choice2])

        next_gen = copy.deepcopy(next_gen)

        for chromosome in next_gen[NUM_ELITES*NUM_COPIES:]:
            chromosome.mutate(self.altSections)

        self.chromosomes = next_gen
    
