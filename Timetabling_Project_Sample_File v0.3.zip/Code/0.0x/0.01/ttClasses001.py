####################################################################################################
## File Name: ttClasses001.py
## Date: 2017-05-21
## Description: Contains the classes for the timetabling software.
##              This version includes a Chromosome object that can generate and decode itself.
####################################################################################################

import random

def clear_end(bits, new_end):
    '''Set all bits after a certain slice to 0.

    >>> bits = int('0b1010101', 2)
    >>> bin(clear_end(bits, 3))
    '0b101'
    '''
    # creates a string of 1's of length (new_end)
    mask = (1 << new_end) - 1
    # bitwise AND sets all bits after that string to 0
    return bits & mask        

def get_bits(bits, start, stop):
    '''Return the bits between two slices of a binary string

    >>> bits = int('0b1110111', 2)
    >>> bin(get_bits(bits, 2, 6))
    '0b1101'
    '''
    # remove the bits after the stop slice and before the start slice 
    return clear_end(bits, stop) >> start                                      

def concatenate_bits(left, right, right_length):
    '''Add the bits of a binary string to those of another.

    >>> left = int('0b10101', 2)
    >>> right = int('0b1111', 2)
    >>> bin(concatenate_bits(left, right, 4))
    '0b101011111'
    >>> bin(concatenate_bits(left, right, 8))
    '0b1010100001111'
    '''
    # bit shift left the correct number of spaces, then set the bits of the right using bitwise OR
    return (left << right_length) | right

class Chromosome(object):
    '''Object describing the timeslot in which each course section runs.

    Consists of a string of bits and an associated fitness score. Every three
    bits represents a timeslot (from 0-7) in which a certain course section runs.
    '''
    def __init__(self, sections, bits = None):
        size = sections * 3
        if bits is None:
            bits = int(random.getrandbits(size))
        self.size = size
        self.bits = bits
        self.fitness = 0

    def decode(self):
        '''Returns a list of integers from 0-7, representing the timeslots of each section.'''
        periods = []
        for i in xrange(0, self.size, 3):               # break the chromosome into threes
            period = int(get_bits(self.bits, i, i+3))   # and create a list of the associated
            periods.append(period)                      # integers from 0-7
        return periods
            
        
