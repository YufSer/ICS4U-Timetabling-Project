####################################################################################################
## File Name: ttMain004.py
## Date: 2017-06-01
## Description: Main program for the timetabling software.
##              This version attempts to speed up the evaluation of the large chromosome.
####################################################################################################

from ttClasses005 import *
import os, sqlite3

# get the path to selections.db in the Data/Databases directory
path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'Data', 'Databases', 'selections.db'))

# get 50 records from the Selections table
con = sqlite3.connect(path)
cur = con.cursor()
cur.execute('SELECT StudentNumber, C1, C2, C3, C4, C5, C6, C7, C8 FROM Selections')
data = cur.fetchall()
con.close()

toIndex = {}
toSection = []
enrollment = []
students = []
st_nums = []
partners = []

i = 0
for student in data:
    st_nums.append(student[0])
    students.append([])
    
    for course in student[1:]:
        if course is not None and 'ZLUN' not in course and 'ZSM' not in course:
            section = 1
            assigned = False
            
            while not assigned:
                name = course + '-' + '{0:0>2}'.format(section)
                
                if name not in toIndex:
                    toIndex[name] = i
                    toSection.append(name)
                    enrollment.append(0)
                    partners.append([])
                    i += 1

                j = toIndex[name]
                if enrollment[j] < 28:
                    students[-1].append(j)
                    enrollment[j] += 1
                    assigned = True                

                section += 1

for key1 in toIndex:
    for key2 in toIndex:
        if key1[:-3] == key2[:-3]:
            partners[toIndex[key1]].append(toIndex[key2])

chromosome_size = len(toIndex) * 3
population = Population(chromosome_size, students, partners)

population.update_fitnesses()
print population.best.fitness

while True:
    for i in xrange(100):
        population.run_generation()

    population.update_fitnesses()
    print population.best.fitness
