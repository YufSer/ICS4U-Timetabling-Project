####################################################################################################
## File Name: ttMain007.py
## Date: 2017-06-08
## Description: Main program for the timetabling software.
##              This version fixes the copying of 2D lists.
####################################################################################################

from ttClasses007 import *
import os, sqlite3, time

# get the path to selections.db in the Data/Databases directory
path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'Data', 'Databases', 'selections.db'))

# get 50 records from the Selections table
con = sqlite3.connect(path)
cur = con.cursor()
cur.execute('SELECT StudentNumber, C1, C2, C3, C4, C5, C6, C7, C8 FROM Selections')
data = cur.fetchall()
con.close()

sectionToIndex = {}     # relate a section name to an index
indexToSection = []     # relate an index to a section name
altSections = []        # sections of the same course for each section
enrollment = []         # number of students enrolled in each section - only used to calculate how many sections are required

students = []           # sections in which each student is enrolled
st_nums = []            

# create the minimum number of sections of each course required to hold all students
i = 0   # index of the next section to be created
for student in data:
    students.append([])
    st_nums.append(student[0])
    
    for course in student[1:]:
        if course is not None and 'ZLUN' not in course and 'ZSM' not in course:
            sectionNum = 1                                              # starting with section number 1
            assigned = False                                                        
            while not assigned:
                section = course + '-' + '{0:0>2}'.format(sectionNum)   # format the section name
    
                if section not in sectionToIndex:       # if the section does not yet exist, create it
                    sectionToIndex[section] = i
                    indexToSection.append(section)
                    enrollment.append(0)
                    altSections.append([])
                    i += 1

                j = sectionToIndex[section]     # get the index of the section
                if enrollment[j] < 28:          # if the section still has spaces open
                    students[-1].append(j)      # assign it to the student
                    enrollment[j] += 1
                    assigned = True

                sectionNum += 1     # continue to the next section number

# populate the alternative sections list
for section in sectionToIndex:
    for altSection in sectionToIndex:
        if section[:-3] == altSection[:-3]:
            altSections[sectionToIndex[section]].append(sectionToIndex[altSection])

# chromosome is decoded into numbers from 0 to 7, so 3 bits are required for each number
chromosome_size = i * 3
pop = Population(chromosome_size, students, altSections)

# name the log file according to the start date and time, as well as the file name of this program
startTime = time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())
fileName = startTime + '_' + os.path.basename(os.path.splitext(__file__)[0]) + '.txt'
path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'Logs', fileName))

with open(path, 'w') as f:
    pop.update_fitnesses()
    f.write(str(pop.best.fitness) + '\n')
    print pop.best.fitness

    while True:
        for i in xrange(100):
            pop.run_generation()

        pop.update_fitnesses()
        f.write(str(pop.best.fitness) + '\n')
        print pop.best.fitness
