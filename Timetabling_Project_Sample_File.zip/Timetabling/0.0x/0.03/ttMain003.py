####################################################################################################
## File Name: ttMain003.py
## Date: 2017-05-24
## Description: Main program for the timetabling software.
##              This version runs the genetic algorithm to determine the optimal arrangment of
##              timeslots.
####################################################################################################

from ttClasses003 import *
import os, sqlite3

# get the path to selections.db in the Data/Databases directory
path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'Data', 'Databases', 'selections.db'))

# get 50 records from the Selections table
con = sqlite3.connect(path)
cur = con.cursor()
cur.execute('SELECT StudentNumber, C1, C2, C3, C4, C5, C6, C7, C8 FROM Selections')
data = cur.fetchall()

con.close()

toIndex = {}        # dictionary relating a course section name to an index
toCourse = []       # list relating an index to a course section name
enrollment = []     # number of students placed in each section
students = []       # each student, along with the course sections assigned to them

# this loop generates as many course sections as is necessary to enroll each student in all of their chosen courses
i = 0
for student in data:
    
    # each student record will be a tuple of the form (Student Number, [Assigned Section Indices])
    students.append((student[0], []))

    # iterate through the student's selected courses
    for course in student[1:]:
        
        # ZLUN and ZSM are not actual courses
        if course is not None and 'ZLUN' not in course and 'ZSM' not in course:
            
            # starting with the first section of the course
            section = 1

            # loop until a section is assigned to the student
            assigned = False
            while not assigned:
                
                # the name of the section is the course code plus the section number
                name = course + '-' + '{0:0>2}'.format(section)

                # if the section does not exist, create it with 0 students enrolled
                if name not in toIndex:
                    toIndex[name] = i
                    toCourse.append(name)
                    enrollment.append(0)
                    i += 1

                # if the section has fewer than 28 students, assign the section to the student
                j = toIndex[name]
                if enrollment[j] < 28:
                    students[-1][1].append(j)
                    enrollment[j] += 1
                    assigned = True

                # check the next section if this one was full
                section += 1

# create some random chromosomes that assign each section to a certain period
chromosome_size = len(toIndex) * 3
population = Population(chromosome_size)

population.update_fitnesses(students)
print population.best.fitness

while True:
    for i in xrange(100):
        population.run_generation(students)

    population.update_fitnesses(students)
    print population.best.fitness
